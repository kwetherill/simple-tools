# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

"Claude Hello" is a Manifest V3 Chrome extension — a URL credential manager. It has no build step, no dependencies, and no package manager. The extension consists of exactly three files.

## Loading the Extension

To test changes, load the extension unpacked in Chrome:

1. Open `chrome://extensions`
2. Enable "Developer mode" (top-right toggle)
3. Click "Load unpacked" and select this directory
4. After any code change, click the reload icon on the extension card

The popup cannot be opened directly as an HTML file — `chrome.storage.local` is unavailable outside the extension context and the script will halt with an error message.

## Architecture

All logic lives in `popup.js` with no modules or bundling:

- **Storage**: `chrome.storage.local` under two keys — `"credentials"` (array of `{url, user, pass}` objects) and `"formDraft"` (persists in-progress form state across popup open/close cycles).
- **Rendering**: `renderList()` builds the entry list via `innerHTML`. The `escape()` helper XSS-sanitizes all user data before insertion.
- **Active-tab highlighting**: On init, `chrome.tabs.query` fetches the current tab's origin; entries whose URL shares that origin get the `.active` CSS class and a left-border highlight.
- **URL field**: Optional — if left blank, the current tab's origin is used as the URL (via the input's placeholder value).
- **Edit flow**: A module-level `editingIndex` variable tracks whether the form is in add (`-1`) or edit mode (array index). The submit button text and color change accordingly.

## Permissions

Declared in `manifest.json`: `storage` (for `chrome.storage.local`) and `tabs` (for `chrome.tabs.query` to read the active tab URL).
