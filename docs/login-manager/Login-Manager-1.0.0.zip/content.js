const SELECTED_KEY = "selectedCred";

let autoCloseTimer = null;

function removeOverlay() {
  clearTimeout(autoCloseTimer);
  document.getElementById("claude-cred-host")?.remove();
}

function makeChip(displayText, value) {
  const chip = document.createElement("span");
  chip.textContent = displayText;
  Object.assign(chip.style, {
    cursor: "pointer",
    padding: "3px 8px",
    borderRadius: "4px",
    fontWeight: "500",
    color: "#1a1a1a",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    maxWidth: "160px",
  });

  chip.addEventListener("mouseenter", () => {
    chip.style.background = "#eff6ff";
    chip.style.color = "#0063B2";
  });
  chip.addEventListener("mouseleave", () => {
    chip.style.background = "";
    chip.style.color = "#1a1a1a";
  });

  let copyTimer = null;
  chip.addEventListener("click", () => {
    navigator.clipboard.writeText(value).catch(() => {});
    const orig = chip.textContent;
    chip.textContent = "Copied!";
    clearTimeout(copyTimer);
    copyTimer = setTimeout(() => { chip.textContent = orig; }, 1000);
  });

  return chip;
}

function showOverlay(user, pass) {
  removeOverlay();

  const host = document.createElement("div");
  host.id = "claude-cred-host";
  Object.assign(host.style, {
    position: "fixed",
    bottom: "16px",
    right: "16px",
    zIndex: "2147483647",
    background: "#fff",
    border: "1px solid #e5e7eb",
    borderRadius: "8px",
    boxShadow: "0 4px 16px rgba(0,0,0,0.12)",
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    fontSize: "13px",
    display: "flex",
    alignItems: "center",
    gap: "4px",
    padding: "6px 10px",
  });

  const divider = () => {
    const d = document.createElement("span");
    d.textContent = "|";
    Object.assign(d.style, { color: "#e5e7eb", userSelect: "none" });
    return d;
  };

  const closeBtn = document.createElement("button");
  closeBtn.textContent = "Close";
  Object.assign(closeBtn.style, {
    background: "none",
    border: "none",
    cursor: "pointer",
    color: "#9ca3af",
    fontSize: "13px",
    fontFamily: "inherit",
    padding: "3px 8px",
    borderRadius: "4px",
    whiteSpace: "nowrap",
  });
  closeBtn.addEventListener("mouseenter", () => {
    closeBtn.style.color = "#374151";
    closeBtn.style.background = "#f3f4f6";
  });
  closeBtn.addEventListener("mouseleave", () => {
    closeBtn.style.color = "#9ca3af";
    closeBtn.style.background = "";
  });
  closeBtn.addEventListener("click", () => {
    chrome.storage.local.remove(SELECTED_KEY);
    removeOverlay();
  });

  const passChip = makeChip("\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022", pass);

  const eyeBtn = document.createElement("span");
  eyeBtn.textContent = "Show";
  Object.assign(eyeBtn.style, {
    cursor: "pointer",
    color: "#9ca3af",
    fontSize: "12px",
    userSelect: "none",
    flexShrink: "0",
  });
  eyeBtn.addEventListener("mouseenter", () => { eyeBtn.style.color = "#374151"; });
  eyeBtn.addEventListener("mouseleave", () => { eyeBtn.style.color = "#9ca3af"; });
  eyeBtn.addEventListener("click", () => {
    const show = passChip.textContent === "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022";
    passChip.textContent = show ? pass : "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022";
    eyeBtn.textContent = show ? "Hide" : "Show";
  });

  host.appendChild(makeChip(user, user));
  host.appendChild(divider());
  host.appendChild(passChip);
  host.appendChild(eyeBtn);
  host.appendChild(divider());
  host.appendChild(closeBtn);

  document.body.appendChild(host);

  clearTimeout(autoCloseTimer);
  autoCloseTimer = setTimeout(() => {
    chrome.storage.local.remove(SELECTED_KEY);
    removeOverlay();
  }, 30_000);
}

let navCountUpdated = false;

function checkAndShow(fromStorageChange = false) {
  chrome.storage.local.get(SELECTED_KEY, (result) => {
    const cred = result[SELECTED_KEY];
    if (!cred) { removeOverlay(); return; }
    if (cred.origin !== window.location.origin) { removeOverlay(); return; }

    const navCount = cred.navCount || 0;
    if (navCount > 1) {
      chrome.storage.local.remove(SELECTED_KEY);
      removeOverlay();
      return;
    }

    // Only increment on actual page loads, not on storage-change callbacks,
    // to avoid a feedback loop where our own write re-triggers this function.
    if (!fromStorageChange && !navCountUpdated) {
      navCountUpdated = true;
      chrome.storage.local.set({ [SELECTED_KEY]: { ...cred, navCount: navCount + 1 } });
    }

    showOverlay(cred.user, cred.pass);
  });
}

checkAndShow();

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && SELECTED_KEY in changes) {
    checkAndShow(true);
  }
});
