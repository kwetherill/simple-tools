---
name: push-simple-tool
description: Zips the project files and saves the release to the releases folder. Use when the user says "push", "release", "zip", "package", or "push-simple-tool".
---

Create a zip release of this project by running the following steps:

1. Create the `releases` folder if it doesn't exist.
2. Generate a timestamped filename in the format: `release-YYYY-MM-DD_HH-MM-SS.zip`
3. Zip all files and folders in the current directory, excluding the `releases` folder and `.git` folder.
4. Save the zip to `releases/<timestamped-filename>.zip`.

Run this exact command (adjust only the timestamp at runtime):

```bash
mkdir -p releases && zip -r "releases/release-$(date +%Y-%m-%d_%H-%M-%S).zip" . --exclude "releases/*" --exclude ".git/*"
```

After the command completes, confirm the zip was created and report its filename and size to the user.
