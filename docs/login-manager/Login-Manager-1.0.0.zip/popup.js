const STORAGE_KEY  = "credentials";
const DRAFT_KEY    = "formDraft";
const SELECTED_KEY = "selectedCred";

// Guard: chrome.storage is only available in extension context
if (!chrome?.storage?.local) {
  document.getElementById("empty").textContent =
    "Open this via the Chrome extension toolbar, not as a file.";
  document.getElementById("add-form").style.display = "none";
  throw new Error("chrome.storage.local unavailable — not running as an extension.");
}

function loadEntries(cb) {
  chrome.storage.local.get(STORAGE_KEY, (result) => {
    cb(result[STORAGE_KEY] || []);
  });
}

function saveEntries(entries, cb) {
  chrome.storage.local.set({ [STORAGE_KEY]: entries }, cb);
}

function escape(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function originOf(url) {
  try { return new URL(url).origin; } catch { return null; }
}

// ── Draft persistence ──
function saveDraft() {
  if (editingIndex >= 0) return;
  const draft = {
    url:  document.getElementById("f-url").value,
    user: document.getElementById("f-user").value,
    pass: document.getElementById("f-pass").value,
  };
  chrome.storage.local.set({ [DRAFT_KEY]: draft });
}

function clearDraft() {
  chrome.storage.local.remove(DRAFT_KEY);
}

// ── List ──
let currentOrigin = null;
let cachedEntries  = [];

function renderList(entries) {
  cachedEntries = entries;
  const list = document.getElementById("list");
  const empty = document.getElementById("empty");

  list.querySelectorAll(".entry").forEach((el) => el.remove());

  if (entries.length === 0) {
    empty.style.display = "block";
    return;
  }

  empty.style.display = "none";

  entries.forEach((entry, index) => {
    const row = document.createElement("div");
    const matches = currentOrigin && originOf(entry.url) === currentOrigin;
    row.className = "entry" + (matches ? " active" : "");
    row.dataset.index = index;
    row.innerHTML = `
      <div class="entry-info">
        <div class="entry-url" data-url="${escape(entry.url)}" title="${escape(entry.url)}">${escape(entry.url)}</div>
        <div class="entry-creds">
          <span class="copy-user" data-value="${escape(entry.user)}" title="Click to copy username">${escape(entry.user)}</span>
          <span class="copy-pass" data-value="${escape(entry.pass)}" title="Click to copy password">••••••••</span>
          <button class="toggle-pass" type="button" title="Show/hide password"><img src="images/eye-icon.svg" alt="" /></button>
        </div>
      </div>
      <div class="entry-actions">
        <button class="edit" data-index="${index}" title="Edit"><img src="images/edit-icon.svg" alt="Edit" /></button>
        <button class="remove" data-index="${index}" title="Remove"><img src="images/x-icon.svg" alt="Remove" /></button>
      </div>
    `;
    list.appendChild(row);
  });
}

// ── Toast ──
let toastTimer = null;

function showToast(msg) {
  const toast = document.getElementById("toast");
  toast.textContent = msg;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 1500);
}

function copyText(text, label) {
  navigator.clipboard.writeText(text).then(() => showToast(`${label} copied`));
}

// ── Edit state ──
let editingIndex = -1;
const submitBtn = document.getElementById("submit-btn");
const deleteBtn = document.getElementById("delete-btn");
const clearBtn  = document.getElementById("clear-btn");

function startEdit(entry, index) {
  editingIndex = index;
  document.getElementById("f-url").value  = entry.url;
  document.getElementById("f-user").value = entry.user;
  document.getElementById("f-pass").value = entry.pass;
  submitBtn.textContent = "Update";
  submitBtn.classList.add("editing");
  deleteBtn.style.display = "block";
  clearBtn.textContent = "Cancel";
  updateClearButtons();
  document.getElementById("f-url").focus();
  clearDraft();
}

function resetForm() {
  editingIndex = -1;
  document.getElementById("add-form").reset();
  document.getElementById("f-pass").type = "password";
  document.querySelector("#toggle-pass img").src = "images/eye-icon.svg";
  submitBtn.textContent = "Add";
  submitBtn.classList.remove("editing");
  deleteBtn.style.display = "none";
  clearBtn.textContent = "Clear";
  updateClearButtons();
  clearDraft();
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]?.url) {
      document.getElementById("f-url").placeholder = originOf(tabs[0].url) || tabs[0].url;
    }
  });
}

// ── Clear buttons ──
function updateClearButtons() {
  document.querySelectorAll(".clear-btn").forEach((btn) => {
    const input = document.getElementById(btn.dataset.target);
    btn.style.display = input.value ? "block" : "none";
  });
  document.getElementById("toggle-pass").style.display =
    document.getElementById("f-pass").value ? "flex" : "none";
}

document.querySelectorAll(".input-wrap input").forEach((input) => {
  input.addEventListener("input", () => {
    updateClearButtons();
    saveDraft();
  });
});

document.querySelectorAll(".clear-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const input = document.getElementById(btn.dataset.target);
    input.value = "";
    input.focus();
    updateClearButtons();
    saveDraft();
  });
});

// ── Clear button ──
document.getElementById("clear-btn").addEventListener("click", resetForm);

// ── Password visibility toggle (form) ──
document.getElementById("toggle-pass").addEventListener("click", () => {
  const input = document.getElementById("f-pass");
  const img   = document.querySelector("#toggle-pass img");
  const show  = input.type === "password";
  input.type  = show ? "text" : "password";
  img.src     = show ? "images/eye-closed-icon.svg" : "images/eye-icon.svg";
});

// ── Delete button (edit mode only) ──
deleteBtn.addEventListener("click", () => {
  if (editingIndex < 0) return;
  if (!confirm("Delete this entry?")) return;
  const idx = editingIndex;
  resetForm();
  loadEntries((entries) => {
    entries.splice(idx, 1);
    saveEntries(entries, () => renderList(entries));
  });
});

// ── List interactions ──
document.getElementById("list").addEventListener("click", (e) => {
  const editBtn = e.target.closest("button.edit");
  if (editBtn) {
    const index = parseInt(editBtn.dataset.index, 10);
    loadEntries((entries) => startEdit(entries[index], index));
    return;
  }

  const removeBtn = e.target.closest("button.remove");
  if (removeBtn) {
    if (!confirm("Remove this entry?")) return;
    const index = parseInt(removeBtn.dataset.index, 10);
    if (editingIndex === index) resetForm();
    loadEntries((entries) => {
      entries.splice(index, 1);
      saveEntries(entries, () => renderList(entries));
    });
    return;
  }

  // Select entry for overlay (any click that isn't edit/delete)
  const entryEl = e.target.closest(".entry");
  if (entryEl) {
    const idx = parseInt(entryEl.dataset.index, 10);
    const entry = cachedEntries[idx];
    if (entry) {
      const origin = originOf(entry.url);
      if (origin) {
        chrome.storage.local.set({ [SELECTED_KEY]: { user: entry.user, pass: entry.pass, origin, navCount: 0 } });
      }
    }
  }

  const urlEl = e.target.closest(".entry-url");
  if (urlEl) {
    chrome.tabs.create({ url: urlEl.dataset.url });
    return;
  }

  const userEl = e.target.closest(".copy-user");
  if (userEl) {
    copyText(userEl.dataset.value, "Username");
    return;
  }

  const passEl = e.target.closest(".copy-pass");
  if (passEl) {
    copyText(passEl.dataset.value, "Password");
    return;
  }

  const togglePassBtn = e.target.closest(".toggle-pass");
  if (togglePassBtn) {
    const passSpan = togglePassBtn.previousElementSibling;
    const img      = togglePassBtn.querySelector("img");
    const show     = passSpan.textContent === "••••••••";
    passSpan.textContent = show ? passSpan.dataset.value : "••••••••";
    img.src = show ? "images/eye-closed-icon.svg" : "images/eye-icon.svg";
    return;
  }
});

// ── Form submit ──
document.getElementById("add-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const error = document.getElementById("error");
  error.textContent = "";

  const urlInput = document.getElementById("f-url");
  const url  = urlInput.value.trim() || urlInput.placeholder;
  const user = document.getElementById("f-user").value.trim();
  const pass = document.getElementById("f-pass").value;

  if (!url || !user || !pass) {
    error.textContent = "All fields are required.";
    return;
  }

  loadEntries((entries) => {
    if (editingIndex >= 0) {
      entries[editingIndex] = { url, user, pass };
    } else {
      entries.push({ url, user, pass });
    }
    saveEntries(entries, () => {
      renderList(entries);
      resetForm();
    });
  });
});

// ── Cancel on close ──
window.addEventListener("pagehide", () => {
  if (editingIndex >= 0) clearDraft();
});

// ── Init ──
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (tabs[0]?.url) {
    currentOrigin = originOf(tabs[0].url);
    document.getElementById("f-url").placeholder = currentOrigin || tabs[0].url;
  }

  // Restore draft if one exists
  chrome.storage.local.get(DRAFT_KEY, (result) => {
    const draft = result[DRAFT_KEY];
    if (draft && (draft.url || draft.user || draft.pass)) {
      document.getElementById("f-url").value  = draft.url  || "";
      document.getElementById("f-user").value = draft.user || "";
      document.getElementById("f-pass").value = draft.pass || "";
      updateClearButtons();
    }
    loadEntries(renderList);
  });
});
